#!/usr/bin/env python3

# Python modules
import hashlib

# 3rd party modules
import sysv_ipc

# Utils for this demo
import utils

params = utils.read_params()

# Mrs. Premise has already created the message queue. I just need a handle to it.
mq = sysv_ipc.MessageQueue(params["KEY"])

what_i_sent = ""

for i in range(0, params["ITERATIONS"]):
    utils.say(f"iteration {i}")

    s, _ = mq.receive()
    s = s.decode()
    utils.say(f"Received {s}")

    while s == what_i_sent:
        # Nothing new; give Mrs. Premise another chance to respond.
        mq.send(s)

        s, _ = mq.receive()
        s = s.decode()
        utils.say(f"Received {s}")

    if what_i_sent:
        what_i_sent = what_i_sent.encode()
        try:
            assert(s + 'x' == hashlib.md5(what_i_sent).hexdigest())
        except AssertionError:
            raise AssertionError(f"Message corruption after {i} iterations.")
    # else:
        # When what_i_sent is blank, this is the first message which
        # I always accept without question.

    # MD5 the reply and write back to Mrs. Premise.
    s = hashlib.md5(s.encode()).hexdigest()
    utils.say(f"Sending {s}")
    mq.send(s)
    what_i_sent = s


utils.say("")
utils.say(f"{i + 1} iterations complete")
